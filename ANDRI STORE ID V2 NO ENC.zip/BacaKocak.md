──────────────────────────────
✧  ANDRI STORE V2 INFO
──────────────────────────────

👨‍💻 Developer  : Andri Store  
📜 Script Asli  : Andri Store v2
🗓️ Dibuat       : 02 Desember 2025
🛍️ Rilis Resmi  : 31 Januari 2026

🌐 WEBSITE RESMI      : https://lynk.id/adshopdigital  
▶️ YOUTUBE CHANNEL: https://www.youtube.com/@andristoreID

──────────────────────────────
🚀 CARA MENJALANKAN SCRIPT
──────────────────────────────
1. Buka panel kalian.  
2. Upload file script di menu "Files".  
3. Klik titik tiga (⋮) → pilih "Unarchive".  
4. Masuk ke menu "Startup".  
   - Jika Node.js masih versi 18, ubah ke versi 20.  
     (Disarankan Node.js versi di atas 20)
5. Scroll ke bawah dan lihat "Command Run":  
   - Jika masih tertulis `npm start`, ubah jadi `npm install`.
6. Pergi ke "Console Panel", lalu klik "Start".  
   - Tunggu hingga muncul teks *“60 second ago”*.
7. Kembali ke "Startup", ubah `npm install` ke `npm start`.  
8. Jalankan kembali lewat "Console" dan klik "start" lagi.  
9. Masukkan nomor whatsapp yang mau di hubungkan dengan awalan `628xxxxxxx`.
10. Lalu salin dan masukkan "kode pairing" anda ke whatsapp tujuan. 
   ✅ Selesai, bot siap digunakan.
   
   
⚠️ LARANGAN KERAS MEMPERJUALBELIKAN SCRIPT INI TOLONG HARGAI DEVELOPER (WAJIB DIBACA) ⚠️


──────────────────────────────
🔗 LINK GRUP DAN CHANNEL WHATSAPP
──────────────────────────────
📡 Grup Update   : https://chat.whatsapp.com/C2OL2tRo5MTCY0ij3BVXQM?mode=gi_t
📡 Channel Update : https://whatsapp.com/channel/0029VbBW0L5AYlUPmohzsS0Y
──────────────────────────────
👑 INFO OWNER & KONTAK RESMI
──────────────────────────────
📞 Telegram Utama     : https://t.me/Androstore022  
📞 Whatsapp utama : wa.me/6281934874758
💬 Channel Testimoni  : https://whatsapp.com/channel/0029VbBBPQvD8SDsMDyM8V0v
  

👤 Developer Resmi © aNdri Store 2026

──────────────────────────────
💞 TERIMA KASIH UNTUK SEMUA PENGGUNA 💞
──────────────────────────────

